﻿###########################################
#
# Practical Exercise 6
# Writing a Foreach statement 
# 
###########################################
# Step 1 we are going to import a file then perform a foreach command to extract specific data out of it
# The file contains IPs from GRIZZLY STEPPE – Russian Malicious Cyber Activity
# https://www.us-cert.gov/security-publications/GRIZZLY-STEPPE-Russian-Malicious-Cyber-Activity
$importIP = import-csv .\Class\PE6\JAR-16-20296A.csv

# Now we are going to do a foreach command, to extract the data out of the file
foreach ( $i in $importIP ) {
$i | where-object type -EQ "FQDN" | export-csv .\Class\PE6\FQDN.csv -Append -NoTypeInformation
$i | where-object type -eq "IPV4ADDR" | export-csv .\Class\PE6\IPADDRESS.csv -Append -NoTypeInformation
$i | where-object type -EQ "MD5" | Export-Csv .\Class\PE6\HASH.csv -Append -NoTypeInformation
}

# Now we are going to import the Hash file and and start a scan on your system to see if anything matches the MD5 hashes that were listed
$HashedFiles = Import-Csv .\Class\PE6\HASH.csv
Get-ChildItem  d:\ -Recurse | Get-FileHash -Algorithm MD5 | Where-Object { $HashedFiles.INDICATOR_VALUE -cmatch $_.Hash } | export-csv .\Class\PE6\matchedMalware.csv -append

# Now you have a scanner that can scan computers for custom malware by hash