﻿##################################
# 
# Practical Exercise 10
# Now we are going to use an API to lookup the
# IP Addresses and get their geographical locations 
# from the American Registry for Internet Numbers
#
##################################
# First let's import the IP address that we want to look up
$IPAddress = Import-Csv .\Class\PE10\IPv4.csv

# Now let's lookup every IP address in this list per the ARIN site using the API 
foreach ( $i in $IPAddress ) {
# initial request to get the XML file
[xml]$ARINIP = Invoke-RestMethod "http://whois.arin.net/rest/ip/$($i.IPADDRESS).xml" -Method get
# Now parsing the xml to set some variables
if ( $ARINIP -ne $null ) { 
$ip = $i.IPADDRESS
$handle = $ARINIP.net.handle
$handlepoc = Invoke-RestMethod "https://whois.arin.net/rest/net/$($handle).xml"
[string]$ref = $handlepoc.net.orgRef.handle

# Now performing another lookup to see if I can get the POC for the organization
$POC = Invoke-RestMethod "https://whois.arin.net/rest/org/$($ref)/pocs" -Method Get
$ref = $POC.pocs.pocLinkRef[0].'#text'
$POC = Invoke-RestMethod ($($ref)+".xml") -Method Get

# Now getting properties of the POC List
$org = $poc.poc.companyName
$city = $poc.poc.city
$zipcode = $POC.poc.postalCode
$phone = $poc.poc.phones.phone.number
$streetAddress = $POC.poc.streetAddress.line.'#text'
$email = $poc.poc.emails.email
$state = $POC.poc.'iso3166-2'

# Now creating a new object to export to a file 
$IPINFO = New-Object PSObject 
$IPINFO | Add-Member -Name IP -MemberType NoteProperty -Value $ip
$IPINFO | Add-Member -Name Org -MemberType NoteProperty -Value $org
$IPINFO | Add-Member -Name Street -MemberType NoteProperty -Value $streetAddress
$IPINFO | Add-Member -Name City -MemberType NoteProperty -Value $city
$IPINFO | Add-Member -Name State -MemberType NoteProperty -Value $state
$IPINFO | Add-Member -Name Zip -MemberType NoteProperty -Value $zipcode
$IPINFO | Add-Member -Name Email -MemberType NoteProperty -Value $email
$IPINFO | Add-Member -Name Phone -MemberType NoteProperty -Value $phone

# Now exporting the object properties to a file
$IPINFO | Export-Csv .\Class\PE10\IP_LOCATIONS.CSV -Append -NoTypeInformation
Remove-Variable -Name ARINIP
Remove-Variable -Name IPINFO
Remove-Variable -Name handle
Remove-Variable -Name handlepoc
Remove-Variable -Name POC
Remove-Variable -Name city
Remove-Variable -Name streetAddress
Remove-Variable -Name state
Remove-Variable -Name zipcode
Remove-Variable -Name email
Remove-Variable -Name phone
Remove-Variable -Name ref
Remove-Variable -Name ip
Remove-Variable -Name org
}
}