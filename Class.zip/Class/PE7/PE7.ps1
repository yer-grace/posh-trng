﻿###########################################
#
# Practical Exercise 7
# Writing an IF statement
# 
###########################################
# We are going to import the Grizzly Rose sheet again
# Step 1
$importIP = import-csv .\Class\PE7\JAR-16-20296A.csv

#Step 2 
# Let's run a foreach command and put an IF command in it
# We will extract the IP addresses to a file
foreach ( $i in $importIP ) {
if ( $i.Type -eq "IPV4ADDR" ) {
($i.INDICATOR_VALUE -replace "\[",'') -replace '\]' | Add-Content .\Class\PE7\IPv4.csv
}
}
