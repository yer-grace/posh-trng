﻿###########################################
#
# Practical Exercise 5
# Working with an Array
# 
###########################################
# use import-csv to import the dictionary file under PE5. We will save it as a variable 
$dictionary = import-csv .\Class\PE5\Dictionary.txt

# Perform a count on all items in the dictionary array
$dictionary.count

# Select the first word of the dictionary 
$dictionary[0]

#select the 27,849th word of the dictionary
$dictionary[27849]

#select the first 100 words in the dictionary 
$dictionary[0..99]

# Longest word in the dictionary 
# When we used the import-csv function it treated the word length as a string and not as an int. We need to cast it to an [int] 
$dictionary | foreach { $_.Length = [int]$_.Length }
$longest = $dictionary | sort-object Length -Descending
$longest[0] 