﻿##################################
# 
# Practical Exercise 9
# Importing a module
#
##################################
# In this exercise we will import the virus total module
Import-Module .\Class\PE9\VirusTotal.psm1

# Now do a show-commnad and under the module drop down select Virus Total
# observe the functions that were added
# Now run the following command

$MYAPIKEY = "a836c54a13f0098047b01316171d90cb770f371982e707a721f90b32bb3c499b"
$hash = Get-Hash -file C:\Windows\System32\cmd.exe -hashType MD5
Get-VTReport -VTApiKey $MYAPIKEY -hash $hash