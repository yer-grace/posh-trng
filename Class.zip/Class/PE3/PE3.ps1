﻿###########################################
#
# Practical Exercise 3
# Filtering objects
# Find Files that are larger than 25MB on your system
# 
###########################################
# Step 1 - use get-member to get the properties of the object
get-childitem | get-member

# another way that might help is to use the following command 
Get-ChildItem | select-object *

# Step 2 - write the where-condition
# need to convert MB to B ( 25*1024*1024 ) 
get-childitem c:\ -Recurse  | where-object Length -GE (25*1024*1024)

# step 3 - now add the select-object to only get the name and path
get-childitem c:\ -Recurse  | where-object Length -GE (25*1024*1024) | select-object FullName -ExpandProperty FullName

