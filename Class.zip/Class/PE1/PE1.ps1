﻿###########################################
#
# Practical Exercise 1
# Basic PowerShell Commands
# Run through these different commands to get you started
# with learning how to use PowerShell
#
###########################################

# This will get the items and subitems within a folder 
Get-ChildItem .\ -Recurse

# This will get an item, the example below will get an item in the registry 
get-item -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run

# This will get the property of an item
Get-ItemProperty -Path C:\Windows\System32\cmd.exe

# This will get a list of services
Get-Service

# This will get a list of processes 
Get-Process 

# This will get a list of networkconnections ( must be Windows 8 or greater )
get-nettcpconnections

# This will get a list of help commands
show-command


