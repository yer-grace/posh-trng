﻿###########################################
#
# Practical Exercise 4
# Setting a variable that can be called later
# 
###########################################
# Example set a variable process 
$process = Get-Process

# Now enter $process below in the command line

# Here is an environmentable variable
$env:USERNAME

# here is an example to get all messages in the security log that contain your username 
$MYEVENTS = Get-EventLog -LogName Security | Where-Object Message -CMatch $env:USERNAME


