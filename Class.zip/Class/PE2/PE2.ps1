﻿###########################################
#
# Practical Exercise 2
# Power of the pipe
# Build on basic commands by piping into another 
# command
#
###########################################
# Get a file and then perform a hash of that file
Get-ChildItem C:\Windows\System32\cmd.exe | Get-FileHash -Algorithm SHA256

# Get a process what has a process ID of 4
Get-process | where-object ID –eq 4 | select-object Name

# Get all executables under the C drive
Get-childitem c:\ -recurse | where-object extension –eq .exe

# Get a list of running services and then export them to a file
Get-service | export-csv –path c:\services.csv


